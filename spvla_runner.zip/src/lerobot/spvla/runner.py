"""SP-VLA Inference Runner — alias of AceInferenceRunner.

SP-VLA accelerates VLA inference via model scheduling (skip VLA during
low-motion states) and token pruning (prune unimportant vision tokens).

Use ``mode="spvla"`` for paper accuracy, ``mode="spvla_paper_speed"`` for
speed-optimised, or ``mode="baseline"`` for no acceleration.
"""

from __future__ import annotations
from lerobot.ace.runner import AceInferenceRunner


class SpVlaInferenceRunner(AceInferenceRunner):
    """SP-VLA inference runner — alias of AceInferenceRunner."""
    pass
