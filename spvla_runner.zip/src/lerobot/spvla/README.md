# SP-VLA Runner

SP-VLA accelerates VLA inference via model scheduling and token pruning. This is a thin wrapper around the ACE runner.

## Quick Start

```python
from lerobot.spvla import SpVlaInferenceRunner

runner = SpVlaInferenceRunner(
    policy_path="/path/to/pi05_libero_finetuned",
    mode="spvla",  # paper accuracy preset
    device="cuda:0",
)
action = runner.predict_action(
    images=["cam0.png", "cam1.png"],
    instruction="pick up the red cup",
    state=[0.1, 0.2, 0.3, 0.0, 0.0, 0.0, 1.0],
)
runner.reset()
```

## Presets

| Mode | Alias | Description |
|------|-------|-------------|
| `spvla_paper_acc` | `spvla` | attn_only + velocity pruning + model scheduling |
| `spvla_paper_speed` | — | More aggressive token budget (48-96) |
| `spvla_reference` | — | Reference scoring/scheduling |
| `spvla_schedule_only` | — | Scheduling only, no pruning |
| `spvla_token_only` | — | Token pruning only |
| `baseline` | — | No acceleration |

## CLI

```bash
python -m lerobot.scripts.spvla_infer --list-presets
python -m lerobot.scripts.spvla_infer \
    --policy-path /path/to/model --mode spvla \
    --instruction "task" --image img.png --num-frames 10
```

## nsys

```bash
nsys profile -t cuda -o spvla_profile \
    python -m lerobot.scripts.spvla_infer \
    --policy-path /path/to/model --mode spvla \
    --instruction "task" --image img.png --num-frames 50
```
