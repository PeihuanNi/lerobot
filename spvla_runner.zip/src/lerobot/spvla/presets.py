"""SP-VLA preset configurations.

Available modes: spvla (paper_acc), spvla_paper_speed, spvla_reference,
spvla_schedule_only, spvla_token_only, baseline.
"""

from __future__ import annotations
from typing import Any
from lerobot.ace.presets import (
    DEFAULT_SPVLA_ENV_TASK, _COMMON_POLICY_OVERRIDES, _SPVLA_ENV_TASK_DEFAULTS,
    _SPVLA_PAPER_ACC_OVERRIDES, _SPVLA_PAPER_SPEED_OVERRIDES, _SPVLA_REFERENCE_OVERRIDES,
    _SPVLA_SCHEDULE_ONLY_OVERRIDES, _SPVLA_TOKEN_ONLY_OVERRIDES, _BASELINE_MODE_OVERRIDES,
)

SPVLA_CANONICAL_MODES = ("spvla_paper_acc", "spvla_paper_speed", "spvla_reference", "spvla_schedule_only", "spvla_token_only", "baseline")
SPVLA_MODE_ALIASES = {"spvla": "spvla_paper_acc", "sp_vla": "spvla_paper_acc", "sp-vla": "spvla_paper_acc", "paper_acc": "spvla_paper_acc", "paper_speed": "spvla_paper_speed", "reference": "spvla_reference", "schedule_only": "spvla_schedule_only", "token_only": "spvla_token_only"}
SPVLA_PRESET_DESCRIPTIONS = {
    "spvla_paper_acc": "SP-VLA paper accuracy: attn_only + velocity pruning + model scheduling (64-128 tokens).",
    "spvla_paper_speed": "SP-VLA paper speed: more aggressive token budget (48-96 tokens).",
    "spvla_reference": "SP-VLA reference: reference scoring/scheduling, no token-budget pruning.",
    "spvla_schedule_only": "SP-VLA scheduling only: no token selection/pruning.",
    "spvla_token_only": "SP-VLA token-only: reference scoring with pruning, no model scheduling.",
    "baseline": "No scheduling, no pruning. Plain VLA baseline.",
}

def list_policy_modes(): return SPVLA_CANONICAL_MODES
def describe_policy_modes(): return dict(SPVLA_PRESET_DESCRIPTIONS)
def get_policy_preset(mode, *, env_task=DEFAULT_SPVLA_ENV_TASK): return resolve_policy_mode(mode, env_task=env_task)
def get_all_policy_presets(*, env_task=DEFAULT_SPVLA_ENV_TASK): return {m: get_policy_preset(m, env_task=env_task) for m in SPVLA_CANONICAL_MODES}

def resolve_policy_mode(mode, *, env_task=DEFAULT_SPVLA_ENV_TASK):
    if mode is None: return {}
    from lerobot.ace.presets import resolve_policy_mode as _ace_resolve
    return _ace_resolve(normalize_policy_mode(mode), env_task=env_task)

def normalize_policy_mode(mode):
    n = mode.strip().lower().replace("-", "_")
    n = SPVLA_MODE_ALIASES.get(n, n)
    if n not in SPVLA_CANONICAL_MODES:
        raise ValueError(f"Unsupported SP-VLA mode '{mode}'. Supported: {', '.join(SPVLA_CANONICAL_MODES)}.")
    return n
