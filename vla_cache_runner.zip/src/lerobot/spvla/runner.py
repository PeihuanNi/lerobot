"""SP-VLA Inference Runner.

SP-VLA (Selective Pruning VLA) accelerates VLA inference via two complementary
techniques:
  - Model Scheduling: skip expensive VLA calls during low-motion states, using
    a lightweight ridge-regression generator instead.
  - Token Pruning: prune vision tokens based on importance scores before feeding
    them to the VLA model.

This module re-exports ``AceInferenceRunner`` under the name
``SpVlaInferenceRunner`` so that SP-VLA users have a dedicated namespace.
Use ``mode="spvla"`` (alias for ``spvla_paper_acc``) for the paper-accuracy
preset, or ``mode="spvla_paper_speed"`` for the speed-optimised preset.
"""

from __future__ import annotations

from lerobot.ace.runner import AceInferenceRunner


class SpVlaInferenceRunner(AceInferenceRunner):
    """SP-VLA inference runner — alias of AceInferenceRunner.

    Recommended modes: ``spvla`` (paper accuracy), ``spvla_paper_speed``,
    ``spvla_reference``, ``spvla_schedule_only``, ``spvla_token_only``,
    ``baseline``.
    """

    pass
