"""SP-VLA preset configurations.

This module re-exports the SP-VLA-relevant subset of ACE presets. All preset
resolution ultimately goes through :mod:`lerobot.ace.presets`.

Available modes
---------------
spvla (alias: sp_vla, sp-vla, paper_acc)
    Paper accuracy: attn_only scoring + velocity-based dynamic pruning + model
    scheduling.  Keeps 64–128 vision tokens per camera.

spvla_paper_speed
    More aggressive token budget than paper_acc (48–96 tokens).

spvla_reference
    Reference scoring/scheduling path with no token-budget pruning.

spvla_schedule_only
    Lightweight reference scheduling without token selection/pruning.

spvla_token_only
    Token pruning with reference scoring, no model scheduling.

baseline
    No scheduling, no pruning — plain VLA baseline.
"""

from __future__ import annotations

from typing import Any

# Re-export the full API from the ACE presets module.
from lerobot.ace.presets import (
    DEFAULT_SPVLA_ENV_TASK,
    _CANONICAL_POLICY_MODES,
    _POLICY_MODE_ALIASES,
    _POLICY_PRESET_DESCRIPTIONS,
    _resolve_spvla_env_defaults,
    _ACE_MODE_OVERRIDES,
    _SPVLA_ENV_TASK_DEFAULTS,
    _COMMON_POLICY_OVERRIDES,
    _SPVLA_PAPER_ACC_OVERRIDES,
    _SPVLA_PAPER_SPEED_OVERRIDES,
    _SPVLA_REFERENCE_OVERRIDES,
    _SPVLA_SCHEDULE_ONLY_OVERRIDES,
    _SPVLA_TOKEN_ONLY_OVERRIDES,
    _BASELINE_MODE_OVERRIDES,
)

# ── Canonical modes exposed by the SP-VLA package ──────────────────────────
SPVLA_CANONICAL_MODES = (
    "spvla_paper_acc",
    "spvla_paper_speed",
    "spvla_reference",
    "spvla_schedule_only",
    "spvla_token_only",
    "baseline",
)

SPVLA_MODE_ALIASES = {
    "spvla": "spvla_paper_acc",
    "sp_vla": "spvla_paper_acc",
    "sp-vla": "spvla_paper_acc",
    "paper_acc": "spvla_paper_acc",
    "paper_speed": "spvla_paper_speed",
    "reference": "spvla_reference",
    "schedule_only": "spvla_schedule_only",
    "token_only": "spvla_token_only",
}

SPVLA_PRESET_DESCRIPTIONS = {
    "spvla_paper_acc": (
        "SP-VLA paper accuracy: attn_only scoring + velocity pruning + model scheduling. "
        "Keeps 64–128 vision tokens per camera."
    ),
    "spvla_paper_speed": (
        "SP-VLA paper speed: more aggressive token budget (48–96 tokens) than paper_acc."
    ),
    "spvla_reference": (
        "SP-VLA reference: reference scoring/scheduling path with no token-budget pruning."
    ),
    "spvla_schedule_only": (
        "SP-VLA scheduling only: lightweight reference scheduling without token selection/pruning."
    ),
    "spvla_token_only": (
        "SP-VLA token-only: reference scoring with token pruning but no model scheduling."
    ),
    "baseline": (
        "No scheduling, no pruning. Plain VLA baseline with chunked action generation."
    ),
}


def list_policy_modes() -> tuple[str, ...]:
    return SPVLA_CANONICAL_MODES


def describe_policy_modes() -> dict[str, str]:
    return dict(SPVLA_PRESET_DESCRIPTIONS)


def get_policy_preset(mode: str, *, env_task: str = DEFAULT_SPVLA_ENV_TASK) -> dict[str, Any]:
    return resolve_policy_mode(mode, env_task=env_task)


def get_all_policy_presets(*, env_task: str = DEFAULT_SPVLA_ENV_TASK) -> dict[str, dict[str, Any]]:
    return {
        mode: get_policy_preset(mode, env_task=env_task)
        for mode in SPVLA_CANONICAL_MODES
    }


def resolve_policy_mode(mode: str | None, *, env_task: str = DEFAULT_SPVLA_ENV_TASK) -> dict[str, Any]:
    """Resolve a SP-VLA mode name to its full policy override dict."""
    if mode is None:
        return {}

    normalized = normalize_policy_mode(mode)

    # Delegate to the ACE presets resolver which knows how to build every mode.
    from lerobot.ace.presets import resolve_policy_mode as _ace_resolve

    return _ace_resolve(normalized, env_task=env_task)


def normalize_policy_mode(mode: str) -> str:
    normalized = mode.strip().lower().replace("-", "_")
    normalized = SPVLA_MODE_ALIASES.get(normalized, normalized)
    if normalized not in SPVLA_CANONICAL_MODES:
        supported = ", ".join(SPVLA_CANONICAL_MODES)
        raise ValueError(f"Unsupported SP-VLA mode '{mode}'. Supported modes: {supported}.")
    return normalized
