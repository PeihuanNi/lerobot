# SP-VLA Runner

SP-VLA (Selective Pruning VLA) accelerates VLA inference through two complementary techniques:

- **Model Scheduling**: Skip expensive VLA calls during low-motion states, using a lightweight ridge-regression generator instead.
- **Token Pruning**: Prune vision tokens based on importance scores before feeding them to the VLA model.

## Quick Start

```python
from lerobot.spvla import SpVlaInferenceRunner

# Create runner with paper-accuracy preset
runner = SpVlaInferenceRunner(
    policy_path="/path/to/pi05_libero_finetuned",
    mode="spvla",  # alias for spvla_paper_acc
    env_task="libero_object",
    device="cuda:0",
)

# Predict action from a single frame
action = runner.predict_action(
    images=["camera0.png", "camera1.png"],
    instruction="pick up the red cup",
    state=[0.1, 0.2, 0.3, 0.0, 0.0, 0.0, 1.0],  # 7-DOF robot state
)
print(action.shape)  # (7,)

# Predict full action chunk
chunk = runner.predict_action_chunk(
    images=["camera0.png", "camera1.png"],
    instruction="pick up the red cup",
)
print(chunk.shape)  # (50, 7) — 50 steps, 7-DOF

# Multi-frame inference (stateful: scheduling adapts across frames)
frames = ["frame0.png", "frame1.png", "frame2.png"]
results = runner.predict_action_chunk_sequence(
    frames=frames,
    instruction="pick up the red cup",
)
for r in results:
    print(f"frame {r['frame_index']}: chunk shape {r['action_chunk'].shape}")

# Reset between episodes
runner.reset()
```

## Available Presets

| Mode | Alias | Description |
|------|-------|-------------|
| `spvla_paper_acc` | `spvla`, `sp-vla` | Paper accuracy: attn_only scoring + velocity pruning + model scheduling (64–128 tokens) |
| `spvla_paper_speed` | `paper_speed` | More aggressive token budget (48–96 tokens) |
| `spvla_reference` | `reference` | Reference scoring/scheduling, no token-budget pruning |
| `spvla_schedule_only` | `schedule_only` | Model scheduling only, no token pruning |
| `spvla_token_only` | `token_only` | Token pruning only, no model scheduling |
| `baseline` | — | No scheduling, no pruning — plain VLA |

List presets with resolved parameters:

```bash
python -m lerobot.scripts.spvla_infer --list-presets --env-task libero_object
```

## Key Configuration Parameters

Model Scheduling:
- `model_scheduling_enabled` (bool): Enable ridge-regression scheduling
- `schedule_buffer_size` (int, default=6): Action history buffer size
- `schedule_ratio_threshold` (float, default=0.5): VLA/generator ratio threshold
- `schedule_velocity_min` (float, default=0.04): Min velocity to trigger VLA
- `schedule_velocity_max` (float, default=0.20): Max velocity for generator

Token Pruning:
- `token_selection_enabled` (bool): Enable token scoring/pruning
- `token_prune_enabled` (bool): Enable actual pruning (vs scoring only)
- `grad_score_method` (str): Scoring method — `attn_only`, `ace`, `spvla_reference`
- `dynamic_prune_mode` (str): Dynamic pruning — `none`, `velocity`, `ema`, `accel`
- `min_kept_tokens` / `max_kept_tokens` (int): Token count bounds
- `region_eval_interval` (int): Score every N frames (1 = every frame)

## CLI Usage

```bash
# Basic inference
python -m lerobot.scripts.spvla_infer \
    --policy-path /path/to/model \
    --mode spvla \
    --instruction "pick up the red cup" \
    --image camera0.png \
    --image camera1.png

# With state vector and multiple frames
python -m lerobot.scripts.spvla_infer \
    --policy-path /path/to/model \
    --mode spvla_paper_speed \
    --instruction "open the drawer" \
    --image frame.png \
    --state 0.1,0.2,0.3,0.0,0.0,0.0,1.0 \
    --num-frames 10

# Print resolved config
python -m lerobot.scripts.spvla_infer \
    --policy-path /path/to/model \
    --mode spvla \
    --instruction "task" --image img.png \
    --print-resolved-overrides

# Override specific parameters
python -m lerobot.scripts.spvla_infer \
    --policy-path /path/to/model \
    --mode spvla \
    --instruction "task" --image img.png \
    --policy-override min_kept_tokens=32 \
    --policy-override max_kept_tokens=64
```

## Profiling with nsys

```bash
# Profile with NVIDIA Nsight Systems
nsys profile -t cuda -o spvla_profile \
    python -m lerobot.scripts.spvla_infer \
    --policy-path /path/to/model \
    --mode spvla \
    --instruction "pick up the red cup" \
    --image frame.png \
    --num-frames 50

# View the profile
nsys-ui spvla_profile.nsys-rep
```

## Zip Contents

```
spvla_runner.zip
├── src/lerobot/spvla/          # SP-VLA runner module
│   ├── __init__.py
│   ├── runner.py
│   ├── presets.py
│   └── README.md
├── src/lerobot/ace/            # ACE module (dependency)
├── src/lerobot/policies/       # Policy implementations (pi0, pi05)
├── src/lerobot/configs/        # Configuration classes
├── src/lerobot/scripts/spvla_infer.py  # CLI entry point
├── pyproject.toml              # Package metadata
└── requirements-ubuntu.txt     # Dependencies
```

## Installation

```bash
# Install dependencies
pip install torch torchvision numpy pillow

# Install the package
cd spvla_runner
pip install -e .
```
