"""Standalone VLA-Cache inference entrypoint.

Usage::

    python -m lerobot.scripts.vla_cache_infer --list-presets
    python -m lerobot.scripts.vla_cache_infer \\
        --policy-path /path/to/model --mode vla_cache \\
        --instruction "task" --image img.png --num-frames 10 --print-cache-stats
"""

from __future__ import annotations
import argparse, json
import numpy as np
from lerobot.vla_cache.presets import describe_policy_modes, get_all_policy_presets, list_policy_modes

def _parse_override(override):
    if "=" not in override: raise ValueError(f"Invalid override '{override}'.")
    key, raw = override.split("=", 1)
    low = raw.lower()
    if low in {"true", "false"}: return key, low == "true"
    if low == "null": return key, None
    try: return key, json.loads(raw)
    except json.JSONDecodeError: return key, raw

def _parse_state(raw):
    if raw is None or raw.strip() == "": return None
    return [float(x) for x in raw.split(",")]

def main():
    modes = ", ".join(list_policy_modes())
    parser = argparse.ArgumentParser(description="Standalone VLA-Cache inference entrypoint.")
    parser.add_argument("--policy-path", default=None)
    parser.add_argument("--mode", default="vla_cache", help=f"Preset mode (default: vla_cache). Supported: {modes}.")
    parser.add_argument("--env-task", default="libero_object")
    parser.add_argument("--list-presets", action="store_true")
    parser.add_argument("--print-resolved-overrides", action="store_true")
    parser.add_argument("--instruction", default=None)
    parser.add_argument("--image", dest="images", action="append", default=None)
    parser.add_argument("--state", default=None)
    parser.add_argument("--device", default=None)
    parser.add_argument("--use-amp", action="store_true")
    parser.add_argument("--num-frames", type=int, default=1)
    parser.add_argument("--print-chunk", action="store_true")
    parser.add_argument("--print-cache-stats", action="store_true")
    parser.add_argument("--enable-nsys", action="store_true")
    parser.add_argument("--policy-override", action="append", default=[], metavar="KEY=VALUE")
    args = parser.parse_args()

    if args.list_presets:
        print(json.dumps({"method": "vla_cache", "env_task": args.env_task, "preset_descriptions": describe_policy_modes(), "resolved_presets": get_all_policy_presets(env_task=args.env_task)}, indent=2, sort_keys=True))
        return
    if args.policy_path is None: parser.error("--policy-path is required.")
    if args.instruction is None: parser.error("--instruction is required.")
    if not args.images: parser.error("At least one --image is required.")

    policy_overrides = dict(_parse_override(x) for x in args.policy_override)
    from lerobot.vla_cache import VlaCacheInferenceRunner
    runner = VlaCacheInferenceRunner(args.policy_path, mode=args.mode, env_task=args.env_task, policy_overrides=policy_overrides, device=args.device, use_amp=args.use_amp if args.use_amp else None, enable_nsys=args.enable_nsys)
    if args.print_resolved_overrides:
        print(json.dumps(runner.get_effective_policy_overrides(), indent=2, sort_keys=True))

    state = _parse_state(args.state)
    for i in range(args.num_frames):
        print(f"frame {i}:")
        if args.print_chunk:
            chunk = runner.predict_action_chunk(images=args.images, instruction=args.instruction, state=state)
            print("chunk shape:", chunk.shape)
            print(chunk)
        else:
            action = runner.predict_action(images=args.images, instruction=args.instruction, state=state)
            print("action shape:", np.asarray(action).shape)
            print(action)
        print("inference info:")
        print(json.dumps(runner.get_last_inference_info(), indent=2, sort_keys=True))
    if args.print_cache_stats:
        print("\ncache statistics:")
        print(json.dumps(runner.get_cache_stats(), indent=2, sort_keys=True))

if __name__ == "__main__":
    main()
