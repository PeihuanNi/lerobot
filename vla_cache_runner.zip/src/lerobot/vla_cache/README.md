# VLA-Cache Runner

VLA-Cache accelerates VLA inference by reusing prefix-cache tokens across consecutive frames. Tokens with high cosine similarity to the previous frame are reused from cache instead of recomputed.

## Quick Start

```python
from lerobot.vla_cache import VlaCacheInferenceRunner

runner = VlaCacheInferenceRunner(
    policy_path="/path/to/pi05_libero_finetuned",
    mode="vla_cache",
    device="cuda:0",
)
action = runner.predict_action(images=["cam0.png"], instruction="pick up the cup")
print(runner.get_cache_stats())
runner.reset()
```

## Presets

| Mode | Description |
|------|-------------|
| `vla_cache` | Default: cosine similarity reuse with layer-wise scheduling |
| `vla_cache_no_schedule` | Without layer-wise scheduling |
| `vla_cache_aggressive` | reuse_tokens=200, threshold=0.99 |
| `baseline` | No token selection |

## CLI

```bash
python -m lerobot.scripts.vla_cache_infer --list-presets
python -m lerobot.scripts.vla_cache_infer \
    --policy-path /path/to/model --mode vla_cache \
    --instruction "task" --image img.png --num-frames 10 --print-cache-stats
```

## nsys

```bash
nsys profile -t cuda -o vla_cache_profile \
    python -m lerobot.scripts.vla_cache_infer \
    --policy-path /path/to/model --mode vla_cache \
    --instruction "task" --image img.png --num-frames 50
```
