"""VLA-Cache Inference Runner.

VLA-Cache reuses prefix-cache tokens across consecutive frames by computing
cosine similarity between current and previous image patches.

Usage::

    from lerobot.vla_cache import VlaCacheInferenceRunner

    runner = VlaCacheInferenceRunner(
        policy_path="/path/to/pi05_libero_finetuned",
        mode="vla_cache",
        device="cuda:0",
    )
    action = runner.predict_action(images=["cam0.png"], instruction="task")
    print(runner.get_cache_stats())
"""

from __future__ import annotations
from contextlib import ExitStack, contextmanager, nullcontext
from pathlib import Path
from typing import Any, Iterable, Sequence
import numpy as np
import torch

from lerobot.configs.policies import PreTrainedConfig
from lerobot.policies.factory import get_policy_class, make_pre_post_processors
from .presets import DEFAULT_VLACACHE_ENV_TASK, normalize_policy_mode, resolve_policy_mode

try:
    from PIL import Image
except ImportError:
    Image = None

ImageInput = str | Path | np.ndarray | torch.Tensor | Any
ImageInputs = ImageInput | Sequence[ImageInput]


class VlaCacheInferenceRunner:
    def __init__(self, policy_path, *, mode=None, env_task=DEFAULT_VLACACHE_ENV_TASK, policy_overrides=None, device=None, use_amp=None, strict=False, enable_nsys=False):
        self.policy_path = str(policy_path)
        self.mode = normalize_policy_mode(mode) if mode is not None else None
        self.env_task = env_task
        self._enable_nsys = enable_nsys
        self._policy_overrides = resolve_policy_mode(self.mode, env_task=env_task)
        self._policy_overrides.update(policy_overrides or {})
        self.config = self._load_config(device=device, use_amp=use_amp)
        self.device = torch.device(self.config.device)
        self.use_amp = bool(self.config.use_amp)
        policy_class = get_policy_class(self.config.type)
        self.policy = policy_class.from_pretrained(self.policy_path, config=self.config, strict=strict)
        self.preprocessor, self.postprocessor = make_pre_post_processors(
            self.config, pretrained_path=self.policy_path,
            preprocessor_overrides={"device_processor": {"device": str(self.device)}},
        )
        self._last_inference_info = None

    def reset(self):
        self.policy.reset()
        self._last_inference_info = None

    def get_effective_policy_overrides(self):
        return dict(self._policy_overrides)

    def get_last_inference_info(self):
        return dict(self._last_inference_info) if self._last_inference_info is not None else None

    def get_token_selection_debug_state(self):
        raw = self._get_raw_token_selection_state()
        if raw is None:
            return None
        eval_interval = self.config.region_eval_interval if self.config.region_eval_interval > 0 else 1
        next_mode = "eval" if (self.config.score_debug_heatmap or raw.frame_idx % eval_interval == 0) else "prune"
        last_stats = dict(raw.last_stats or {})
        lfm = "eval" if last_stats.get("eval") == "Y" else ("prune" if last_stats.get("eval") == "N" else None)
        return {"frame_idx": int(raw.frame_idx), "eval_interval": int(eval_interval), "next_frame_mode": next_mode, "last_frame_mode": lfm, "eval_frame_count": int(raw.eval_frame_count), "token_selection_enabled": bool(getattr(self.config, "token_selection_enabled", False)), "token_prune_enabled": bool(getattr(self.config, "token_prune_enabled", False)), "last_stats": last_stats}

    def get_cache_stats(self):
        raw = self._get_raw_token_selection_state()
        if raw is None:
            return {"error": "no token selection state"}
        tr, tb = int(raw.total_reused), int(raw.total_reusable)
        latency = getattr(raw, "cuda_latency_ms", None)
        lat_stats = self._latency_stats(latency)
        return {"total_reused": tr, "total_reusable": tb, "avg_reuse_ratio": round(tr / tb, 4) if tb > 0 else 0.0, "cuda_latency": lat_stats, "frame_count": int(raw.frame_idx)}

    def get_last_reuse_info(self):
        raw = self._get_raw_token_selection_state()
        if raw is None:
            return None
        masks = getattr(raw, "last_vla_cache_reuse_masks", None)
        if masks is None:
            return None
        per_cam = []
        for m in masks:
            if m is not None:
                per_cam.append({"reused_tokens": int(m.sum().item()), "total_tokens": int(m.numel()), "reuse_ratio": round(float(m.float().mean().item()), 4)})
            else:
                per_cam.append({"reused_tokens": 0, "total_tokens": 0, "reuse_ratio": 0.0})
        return {"per_camera": per_cam, "total_reused": sum(c["reused_tokens"] for c in per_cam), "total_tokens": sum(c["total_tokens"] for c in per_cam)}

    def predict_action(self, images, instruction, state=None):
        with self._nvtx("vlacache_build_batch"):
            batch = self._build_batch(images=images, instruction=instruction, state=state)
        with self._nvtx("vlacache_preprocess"):
            batch = self.preprocessor(batch)
        before = self.get_token_selection_debug_state()
        with self._inference_context():
            with self._nvtx("vlacache_inference"):
                ac = self.policy.predict_action_chunk(batch)
            with self._nvtx("vlacache_postprocess"):
                ac = self.postprocessor(ac)
        action = ac[0, 0].detach().cpu().numpy()
        self._record(before=before, after=self.get_token_selection_debug_state(), via="action")
        return action

    def predict_action_chunk(self, images, instruction, state=None):
        with self._nvtx("vlacache_build_batch"):
            batch = self._build_batch(images=images, instruction=instruction, state=state)
        with self._nvtx("vlacache_preprocess"):
            batch = self.preprocessor(batch)
        before = self.get_token_selection_debug_state()
        with self._inference_context():
            with self._nvtx("vlacache_inference"):
                ac = self.policy.predict_action_chunk(batch)
            with self._nvtx("vlacache_postprocess"):
                ac = self.postprocessor(ac)
        chunk = ac[0].detach().cpu().numpy()
        self._record(before=before, after=self.get_token_selection_debug_state(), via="chunk")
        return chunk

    def predict_action_chunk_sequence(self, frames, instruction, states=None):
        if states is not None and len(states) != len(frames):
            raise ValueError("states must match frames in length.")
        outputs = []
        for i, imgs in enumerate(frames):
            s = None if states is None else states[i]
            chunk = self.predict_action_chunk(images=imgs, instruction=instruction, state=s)
            outputs.append({"frame_index": i, "action_chunk": chunk, "inference_info": self.get_last_inference_info(), "reuse_info": self.get_last_reuse_info()})
        return outputs

    @contextmanager
    def _nvtx(self, name):
        if self._enable_nsys and self.device.type == "cuda":
            torch.cuda.nvtx.range_push(name)
            try: yield
            finally: torch.cuda.nvtx.range_pop()
        else:
            yield

    @contextmanager
    def _inference_context(self):
        with ExitStack() as s:
            s.enter_context(torch.no_grad())
            if self.device.type == "cuda" and self.use_amp:
                s.enter_context(torch.autocast(device_type=self.device.type))
            else:
                s.enter_context(nullcontext())
            yield

    def _load_config(self, *, device, use_amp):
        cli = [f"--{k}={self._str(v)}" for k, v in self._policy_overrides.items()]
        config = PreTrainedConfig.from_pretrained(self.policy_path, cli_overrides=cli)
        config.pretrained_path = Path(self.policy_path)
        if hasattr(config, "compile_model") and "compile_model" not in self._policy_overrides:
            config.compile_model = False
        if device is not None: config.device = device
        if use_amp is not None: config.use_amp = use_amp
        config.__post_init__()
        return config

    def _build_batch(self, *, images, instruction, state):
        items = list(self.config.image_features.items())
        imgs = list(self._norm_imgs(images))
        batch = {"task": instruction}
        non_empty = [x for x in items if "empty_camera" not in x[0]]
        if len(imgs) != len(non_empty):
            raise ValueError(f"Expected {len(non_empty)} image(s), got {len(imgs)}.")
        it = iter(imgs)
        for key, feat in items:
            batch[key] = torch.zeros(feat.shape, dtype=torch.float32) if "empty_camera" in key else next(it)
        sf = self.config.robot_state_feature
        if sf is not None:
            batch["observation.state"] = torch.zeros(sf.shape[0], dtype=torch.float32) if state is None else self._norm_state(state)
        return batch

    def _norm_imgs(self, images):
        if isinstance(images, (str, Path, np.ndarray, torch.Tensor)) or (Image is not None and isinstance(images, Image.Image)):
            raw = [images]
        else:
            raw = list(images)
        for img in raw:
            yield self._norm_img(img)

    def _norm_img(self, image):
        if isinstance(image, (str, Path)):
            if Image is None: raise ImportError("Pillow required.")
            arr = np.asarray(Image.open(image).convert("RGB"))
        elif Image is not None and isinstance(image, Image.Image):
            arr = np.asarray(image.convert("RGB"))
        elif isinstance(image, torch.Tensor):
            arr = image.detach().cpu().numpy()
        else:
            arr = np.asarray(image)
        if arr.ndim == 2: arr = np.repeat(arr[..., None], 3, axis=-1)
        if arr.ndim != 3: raise ValueError(f"Expected 3D image, got {arr.shape}.")
        if arr.shape[-1] in (1, 3): chw = np.transpose(arr, (2, 0, 1))
        elif arr.shape[0] in (1, 3): chw = arr
        else: raise ValueError(f"Cannot infer channel dim from {arr.shape}.")
        chw = np.ascontiguousarray(chw).astype(np.float32)
        if chw.min() >= -1.0 and chw.max() <= 1.0:
            if chw.min() < 0.0: chw = (chw + 1.0) / 2.0
        else:
            chw = chw / 255.0
        return torch.from_numpy(np.clip(chw, 0.0, 1.0))

    def _norm_state(self, state):
        if isinstance(state, torch.Tensor):
            return state.detach().cpu().to(dtype=torch.float32).flatten()
        return torch.as_tensor(state, dtype=torch.float32).flatten()

    def _get_raw_token_selection_state(self):
        return getattr(getattr(self.policy, "model", None), "_token_selection_state", None)

    def _record(self, *, before, after, via):
        if before is None and after is None:
            self._last_inference_info = {"via": via, "fresh_policy_inference": None}
            return
        fresh = idx = mode = None
        if before and after:
            fresh = before["frame_idx"] != after["frame_idx"]
            if fresh: idx, mode = before["frame_idx"], before["next_frame_mode"]
        self._last_inference_info = {"via": via, "fresh_policy_inference": fresh, "processed_frame_idx": idx, "processed_frame_mode": mode, "reuse_info": self.get_last_reuse_info(), "before": before, "after": after}

    @staticmethod
    def _latency_stats(latency_ms):
        if not latency_ms: return {"mean_ms": 0.0, "p50_ms": 0.0, "p95_ms": 0.0, "count": 0}
        arr = sorted(latency_ms)
        c = len(arr)
        return {"mean_ms": round(sum(arr)/c, 3), "p50_ms": round(arr[c//2], 3), "p95_ms": round(arr[min(int(c*0.95), c-1)], 3), "count": c}

    @staticmethod
    def _str(v):
        if isinstance(v, bool): return "true" if v else "false"
        if v is None: return "null"
        return str(v)
