"""VLA-Cache preset configurations.

VLA-Cache accelerates VLA inference by reusing prefix-cache tokens across
consecutive frames via cosine similarity matching.

Available modes
---------------
vla_cache (default)
    Standard VLA-Cache with layer-wise scheduling.
    reuse_tokens=130, protect_top=120, threshold=0.996.

vla_cache_no_schedule
    Without layer-wise reuse scheduling.

vla_cache_aggressive
    Higher reuse (200 tokens), lower threshold (0.99).

baseline
    No token selection — plain VLA.
"""

from __future__ import annotations
from typing import Any

DEFAULT_VLACACHE_ENV_TASK = "libero_object"

_COMMON_POLICY_OVERRIDES: dict[str, Any] = {
    "compile_model": False,
    "n_action_steps": 10,
    "use_l1_regression": False,
    "use_diffusion": True,
    "num_inference_steps": 10,
    "model_scheduling_enabled": False,
    "spvla_reference_enabled": False,
    "token_selection_enabled": True,
    "token_prune_enabled": False,   # VLA-Cache reuses, doesn't prune
}

_VLACACHE_DEFAULTS: dict[str, Any] = {
    "grad_score_method": "vla_cache",
    "vla_cache_reuse_tokens": 130,              # max patch tokens to reuse per image
    "vla_cache_protect_top_tokens": 120,         # top-N always computed fresh
    "vla_cache_similarity_threshold": 0.996,     # min cosine similarity for reuse
    "vla_cache_apply_layer_schedule": True,      # per-layer reuse scheduling
    "vla_cache_growth_factor": 0.55,             # layer schedule growth factor
}

_SCORING_DEFAULTS: dict[str, Any] = {
    "region_eval_interval": 1,
    "region_patch_size": 1,
    "dynamic_prune_mode": "accel",
    "min_kept_tokens": 0,
    "max_kept_tokens": 1_000_000,
}

VLACACHE_MODE_OVERRIDES: dict[str, Any] = {**_COMMON_POLICY_OVERRIDES, **_VLACACHE_DEFAULTS, **_SCORING_DEFAULTS}
VLACACHE_NO_SCHEDULE_OVERRIDES: dict[str, Any] = {**VLACACHE_MODE_OVERRIDES, "vla_cache_apply_layer_schedule": False}
VLACACHE_AGGRESSIVE_OVERRIDES: dict[str, Any] = {**VLACACHE_MODE_OVERRIDES, "vla_cache_reuse_tokens": 200, "vla_cache_protect_top_tokens": 80, "vla_cache_similarity_threshold": 0.99}
BASELINE_MODE_OVERRIDES: dict[str, Any] = {**_COMMON_POLICY_OVERRIDES, "token_selection_enabled": False, "token_prune_enabled": False, "grad_score_method": "vla_cache", "dynamic_prune_mode": "none", "region_eval_interval": 1, "min_kept_tokens": 128, "max_kept_tokens": 128}

_CANONICAL_POLICY_MODES = ("vla_cache", "vla_cache_no_schedule", "vla_cache_aggressive", "baseline")
_POLICY_MODE_ALIASES = {"cache": "vla_cache", "vla-cache": "vla_cache", "vlacache": "vla_cache", "no_schedule": "vla_cache_no_schedule", "aggressive": "vla_cache_aggressive"}
_POLICY_PRESET_DESCRIPTIONS = {
    "vla_cache": "VLA-Cache default: cosine similarity prefix reuse with layer-wise scheduling.",
    "vla_cache_no_schedule": "VLA-Cache without layer-wise scheduling.",
    "vla_cache_aggressive": "VLA-Cache aggressive: reuse_tokens=200, threshold=0.99.",
    "baseline": "No token selection. Plain VLA baseline.",
}

def list_policy_modes(): return _CANONICAL_POLICY_MODES
def describe_policy_modes(): return dict(_POLICY_PRESET_DESCRIPTIONS)
def get_policy_preset(mode, *, env_task=DEFAULT_VLACACHE_ENV_TASK): return resolve_policy_mode(mode, env_task=env_task)
def get_all_policy_presets(*, env_task=DEFAULT_VLACACHE_ENV_TASK): return {m: get_policy_preset(m, env_task=env_task) for m in _CANONICAL_POLICY_MODES}

def resolve_policy_mode(mode, *, env_task=DEFAULT_VLACACHE_ENV_TASK):
    if mode is None: return {}
    n = normalize_policy_mode(mode)
    return dict({"vla_cache": VLACACHE_MODE_OVERRIDES, "vla_cache_no_schedule": VLACACHE_NO_SCHEDULE_OVERRIDES, "vla_cache_aggressive": VLACACHE_AGGRESSIVE_OVERRIDES, "baseline": BASELINE_MODE_OVERRIDES}[n])

def normalize_policy_mode(mode):
    n = mode.strip().lower().replace("-", "_")
    n = _POLICY_MODE_ALIASES.get(n, n)
    if n not in _CANONICAL_POLICY_MODES:
        raise ValueError(f"Unsupported VLA-Cache mode '{mode}'. Supported: {', '.join(_CANONICAL_POLICY_MODES)}.")
    return n
