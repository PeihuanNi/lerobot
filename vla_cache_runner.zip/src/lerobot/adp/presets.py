"""ADP (Adaptive Dynamic Pruning) preset configurations.

ADP uses a binary gate (full vision vs. pruned) that adapts based on motion
history.  When the robot is moving fast, the gate opens to full vision; when
moving slowly, it switches to QK-similarity pruned vision for faster inference.

Available modes
---------------
adp (default)
    QK-similarity scoring + ADP binary gate with adjacent/extrema decision.

adp_mean
    Same as adp but uses mean-based decision instead of adjacent/extrema.

adp_conservative
    Lower keep ratio (0.3), shorter consecutive prune limit (2).

adp_aggressive
    Higher keep ratio (0.7), longer consecutive prune limit (5).

baseline
    No token selection, no pruning — plain VLA baseline.
"""

from __future__ import annotations

from typing import Any

DEFAULT_ADP_ENV_TASK = "libero_object"

_COMMON_POLICY_OVERRIDES: dict[str, Any] = {
    "compile_model": False,
    "n_action_steps": 10,
    "use_l1_regression": False,
    "use_diffusion": True,
    "num_inference_steps": 10,
    "model_scheduling_enabled": False,
    "spvla_reference_enabled": False,
    "token_selection_enabled": True,
    "token_prune_enabled": True,
}

_ADP_GATE_DEFAULTS: dict[str, Any] = {
    "adp_decision_method": "adjacent",       # mean | adjacent
    "adp_adjacent_variant": "extrema",
    "adp_adjacent_extrema_window": 3,
    "adp_adjacent_lookback": 2,
    "adp_adjacent_last_state": False,
    "adp_initial_state": 0,                  # 0=full vision, 1=pruned
    "adp_delta_method": "net",               # net | sum
    "adp_min_delta_pos": 0.0,
    "adp_min_delta_rot": 0.0,
    "adp_hysteresis_up": 0.0,
    "adp_hysteresis_down": 0.0,
    "adp_tol_equal": 0.0,
    "adp_cold_start_windows": 2,
    "adp_limit_consecutive_pruned_enabled": True,
    "adp_limit_max_consecutive_pruned": 3,
}

_QK_SCORING_DEFAULTS: dict[str, Any] = {
    "grad_score_method": "qk_similarity",
    "qk_layer": 0,
    "qk_keep_ratio": 0.5,
    "qk_keep_split": [0.4, 0.6],
    "qk_debug": False,
    "qk_log_topk": 16,
}

_PRUNING_DEFAULTS: dict[str, Any] = {
    "dynamic_prune_mode": "adp",
    "region_eval_interval": 1,
    "region_patch_size": 1,
    "min_kept_tokens": 64,
    "max_kept_tokens": 128,
    "discard_prev_kept_ratio": 0.0,
    "discard_mode": "top",
    "reset_discard_pool_on_gripper_close": False,
    "gripper_close_threshold": 0.0,
}

ADP_MODE_OVERRIDES: dict[str, Any] = {
    **_COMMON_POLICY_OVERRIDES,
    **_QK_SCORING_DEFAULTS,
    **_ADP_GATE_DEFAULTS,
    **_PRUNING_DEFAULTS,
}

ADP_MEAN_MODE_OVERRIDES: dict[str, Any] = {
    **ADP_MODE_OVERRIDES,
    "adp_decision_method": "mean",
}

ADP_CONSERVATIVE_MODE_OVERRIDES: dict[str, Any] = {
    **ADP_MODE_OVERRIDES,
    "qk_keep_ratio": 0.3,
    "adp_limit_max_consecutive_pruned": 2,
}

ADP_AGGRESSIVE_MODE_OVERRIDES: dict[str, Any] = {
    **ADP_MODE_OVERRIDES,
    "qk_keep_ratio": 0.7,
    "adp_limit_max_consecutive_pruned": 5,
}

BASELINE_MODE_OVERRIDES: dict[str, Any] = {
    **_COMMON_POLICY_OVERRIDES,
    "token_selection_enabled": False,
    "token_prune_enabled": False,
    "grad_score_method": "qk_similarity",
    "dynamic_prune_mode": "none",
    "region_eval_interval": 1,
    "min_kept_tokens": 128,
    "max_kept_tokens": 128,
}

_CANONICAL_POLICY_MODES = ("adp", "adp_mean", "adp_conservative", "adp_aggressive", "baseline")

_POLICY_MODE_ALIASES: dict[str, str] = {
    "vla_adp": "adp",
    "vla-adp": "adp",
}

_POLICY_PRESET_DESCRIPTIONS: dict[str, str] = {
    "adp": "ADP default: QK-similarity + binary gate (adjacent/extrema). keep_ratio=0.5.",
    "adp_mean": "ADP with mean-based gate decision.",
    "adp_conservative": "ADP conservative: keep_ratio=0.3, max_consecutive_pruned=2.",
    "adp_aggressive": "ADP aggressive: keep_ratio=0.7, max_consecutive_pruned=5.",
    "baseline": "No token selection, no pruning. Plain VLA baseline.",
}


def list_policy_modes() -> tuple[str, ...]:
    return _CANONICAL_POLICY_MODES


def describe_policy_modes() -> dict[str, str]:
    return dict(_POLICY_PRESET_DESCRIPTIONS)


def get_policy_preset(mode: str, *, env_task: str = DEFAULT_ADP_ENV_TASK) -> dict[str, Any]:
    return resolve_policy_mode(mode, env_task=env_task)


def get_all_policy_presets(*, env_task: str = DEFAULT_ADP_ENV_TASK) -> dict[str, dict[str, Any]]:
    return {mode: get_policy_preset(mode, env_task=env_task) for mode in _CANONICAL_POLICY_MODES}


def resolve_policy_mode(mode: str | None, *, env_task: str = DEFAULT_ADP_ENV_TASK) -> dict[str, Any]:
    if mode is None:
        return {}
    normalized = normalize_policy_mode(mode)
    presets = {
        "adp": ADP_MODE_OVERRIDES,
        "adp_mean": ADP_MEAN_MODE_OVERRIDES,
        "adp_conservative": ADP_CONSERVATIVE_MODE_OVERRIDES,
        "adp_aggressive": ADP_AGGRESSIVE_MODE_OVERRIDES,
        "baseline": BASELINE_MODE_OVERRIDES,
    }
    return dict(presets[normalized])


def normalize_policy_mode(mode: str) -> str:
    normalized = mode.strip().lower().replace("-", "_")
    normalized = _POLICY_MODE_ALIASES.get(normalized, normalized)
    if normalized not in _CANONICAL_POLICY_MODES:
        supported = ", ".join(_CANONICAL_POLICY_MODES)
        raise ValueError(f"Unsupported ADP mode '{mode}'. Supported modes: {supported}.")
    return normalized
