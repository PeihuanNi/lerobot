# ADP Runner

ADP (Adaptive Dynamic Pruning) accelerates VLA inference using a binary gate that adaptively switches between full vision and QK-similarity pruned vision based on action-motion history.

## Quick Start

```python
from lerobot.adp import AdpInferenceRunner

runner = AdpInferenceRunner(
    policy_path="/path/to/pi05_libero_finetuned",
    mode="adp",
    device="cuda:0",
)
action = runner.predict_action(
    images=["camera0.png", "camera1.png"],
    instruction="pick up the red cup",
    state=[0.1, 0.2, 0.3, 0.0, 0.0, 0.0, 1.0],
)
print(runner.get_adp_state())
runner.reset()
```

## Presets

| Mode | Description |
|------|-------------|
| `adp` | QK-similarity + ADP binary gate (adjacent/extrema), keep_ratio=0.5 |
| `adp_mean` | Mean-based gate decision |
| `adp_conservative` | keep_ratio=0.3, max_consecutive_pruned=2 |
| `adp_aggressive` | keep_ratio=0.7, max_consecutive_pruned=5 |
| `baseline` | No token selection |

## CLI

```bash
python -m lerobot.scripts.adp_infer --list-presets
python -m lerobot.scripts.adp_infer \
    --policy-path /path/to/model --mode adp \
    --instruction "task" --image img.png --num-frames 10 --print-adp-state
```

## nsys

```bash
nsys profile -t cuda -o adp_profile \
    python -m lerobot.scripts.adp_infer \
    --policy-path /path/to/model --mode adp \
    --instruction "task" --image img.png --num-frames 50
```
